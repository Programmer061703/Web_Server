# Web_Server

A simple webserver where the backend (python) and front end(typescript) communicate to move sprites on the screen. Then when another user opens the same window it reflects other users movments 
